Chiikawa Paper plugin ID compatibility patch

The plugin calls item models using IDs in the form chiikawa:<species>_part_<part>. The original pack used IDs part_<species>_<part>. This patch adds alias item definitions matching the plugin's expected IDs and points them to the existing geometry models.

Install this ZIP as the resource pack and refresh with F3+T. This addresses item-model ID mismatch only; if geometry/texture still appears wrong, further model/UV testing is needed.
