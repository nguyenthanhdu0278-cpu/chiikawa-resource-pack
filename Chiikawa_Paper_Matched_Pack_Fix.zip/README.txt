Chiikawa Paper 1.21.11 - resource pack compatibility patch

This pack keeps the namespace and item-model IDs expected by ChiikawaPaper-0.3.0.jar.
It also fills three model IDs referenced by the plugin but missing in the uploaded pack:
- part_kurimanju_lefteyebrow
- part_kurimanju_righteyebrow
- part_furuhonya_tail

Install the ZIP as a resource pack, then press F3+T. If your server forces a different pack URL, replace that server pack too.

Important: this fixes missing resource IDs only. It does not rebuild or patch the plugin's display transforms. If the Chiikawa model still appears as a purple/black placeholder or parts overlap, the remaining issue is in the plugin's item-display setup/part transforms, and the plugin source must be changed and rebuilt.
