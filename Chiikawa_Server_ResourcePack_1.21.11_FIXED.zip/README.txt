Chiikawa Paper resource pack prototype

Contains static Java item-model conversions from the supplied Bedrock-style geometry, original entity textures and sound assets. Bone rotations and the original Bedrock animation JSON are NOT yet rendered; this pack is a static model prototype.

Pack format is set to 75 as a 1.21.x-era target; verify the required pack format for your exact Paper client version.

Set the server resource-pack URL in server.properties after hosting this ZIP over HTTPS. A local file path cannot be used by clients.
