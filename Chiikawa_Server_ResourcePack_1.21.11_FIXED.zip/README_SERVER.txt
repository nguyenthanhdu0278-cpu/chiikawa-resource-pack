Chiikawa resource pack for Minecraft Java 1.21.11 (prototype)

INSTALL:
1. This ZIP is packaged with pack.mcmeta and assets/ at the ZIP root.
2. For local testing, copy this ZIP into .minecraft/resourcepacks/ and enable it in Options > Resource Packs.
3. For server auto-download, host this ZIP at a direct HTTPS download URL and configure the server/plugin to send that URL to clients. A local file path is not enough.

VALIDATION:
- JSON files and pack.mcmeta parsed successfully during packaging.
- Every chiikawa item-definition model reference resolves to an existing model JSON.
- Every texture reference found in model JSON resolves to an existing PNG.

LIMITATIONS:
- This pack alone does not make arbitrary 3D entities animate. The plugin must set the matching item-model data on its display entities and position each part correctly.
- The pack contains converted static item models. Bone animation/rig behavior must be implemented by the plugin and is not guaranteed by resource-pack installation alone.
